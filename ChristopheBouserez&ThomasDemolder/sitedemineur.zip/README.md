# 5IPRO-Demineur

Par 2, développer le jeu du démineur avec l’interface en HTML ou en console.

1. Faire un "Fork" de ce dépôt
2. Faire un "clone" sur votre machine
3. Créer un dossier avec vos "Nom Prénom & Nom Prénom" à la racine
4. Développer le jeu dans ce dossier
5. Sauver le développement de chaque fonctionnalité avec un "Commit"
6. Faire des "Push" vers le serveur 
7. Faire une "Pull request" avant le 06/03/2022 à minuit
